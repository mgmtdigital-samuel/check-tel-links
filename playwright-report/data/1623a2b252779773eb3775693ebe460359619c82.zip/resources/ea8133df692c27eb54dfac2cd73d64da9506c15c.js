document.write('<a href="https://www.legitscript.com/websites/?checker_keywords=pathwaytopeacela.com" target="_blank" title="Verify LegitScript Approval for www.pathwaytopeacela.com">');
document.write('<img src="https://static.legitscript.com/seals/42411792.png" alt="Verify Approval for www.pathwaytopeacela.com" width="73" height="79" />');
document.write('</a>');
